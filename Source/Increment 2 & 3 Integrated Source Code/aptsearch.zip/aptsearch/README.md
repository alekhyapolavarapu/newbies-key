# Android---Facebook-Login-Sample
Facebook Login provides a convenient and secure way for people to log in to an app without having to go through a sign-up process first.
